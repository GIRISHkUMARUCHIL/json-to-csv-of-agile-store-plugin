<?php
/*
Plugin Name: JSON to CSV Converter
Description: Converts JSON data from a URL to CSV format and saves it within the plugin directory.
Version: 1.0
Author: JSONtoCSV
*/

// Hook the function to the admin menu
add_action('admin_menu', 'json_to_csv_converter_menu');

function json_to_csv_converter_menu() {
    // Add a submenu page under Tools
    add_submenu_page(
        'tools.php',                    // Parent menu slug
        'JSON to CSV Converter',        // Page title
        'JSON to CSV Converter',        // Menu title
        'manage_options',               // Capability required
        'json-to-csv-converter',        // Menu slug
        'json_to_csv_converter_page'    // Callback function
    );
}

function json_to_csv_converter_page() {
    // Check if form is submitted
    if (isset($_POST['convert_json'])) {
        // Fetch JSON data from URL
        $json_url = 'https://api.epublisher.world/location.ashx?storekey=ab2c8d3f-b4d8-4d37-9d3b-91f9d3cc2b21&call=get#json'; // Replace with your JSON URL
        $response = wp_remote_get($json_url);

        if (is_wp_error($response)) {
            echo '<div class="error"><p>Error fetching JSON data.</p></div>';
        } else {
            $json_data = json_decode(wp_remote_retrieve_body($response), true);
            if ($json_data === null) {
                echo '<div class="error"><p>Error decoding JSON data.</p></div>';
                return;
            }
            
            // Define CSV file path
            $plugin_path = WP_PLUGIN_DIR . '/agile-store-locator/public/import'; // Path to the Agile Store Locations plugin directory
          //  $csv_file_path = $plugin_path . '/data.csv';
            $csv_file_path = WP_CONTENT_DIR . '/uploads/agile-store-locator/cron/data.csv';
            // Convert JSON data to CSV
            if (json_to_csv($json_data, $csv_file_path)) {
                echo '<div class="updated"><p>CSV file has been created successfully.</p></div>';
            } else {
                echo '<div class="error"><p>Error occurred while converting JSON to CSV.</p></div>';
            }
        }
    }

    // Display form
    ?>
    <div class="wrap">
        <h2>JSON to CSV Converter</h2>
        <form method="post" action="">
            <input type="submit" name="convert_json" class="button-primary" value="Convert JSON to CSV">
        </form>
    </div>
    <?php
}

function json_to_csv($json_data, $csv_file_path) {
    // Open CSV file for appending
    $csv_file = fopen($csv_file_path, 'a');

    if (!$csv_file) {
        return false;
    }

    // Load existing data from CSV into memory
    $existing_data = [];
    if (($handle = fopen($csv_file_path, "r")) !== FALSE) {
        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $existing_data[$data[0]] = $data; // Assuming the first column is the ID
        }
        fclose($handle);
    }

    // Define header mapping if file is empty
    if (empty($existing_data)) {
        $header_mapping = array(
           
            'Title' => 'title',
            'Description' => 'description',
            'Street' => 'street',
            'City' => 'city',
            'State' => 'state',
            'Zipcode' => 'postal_code',
            'CountryName' => 'country',
            'Lat' => 'lat',
            'Lon' => 'lng',
            'Telephone' => 'phone',
            'Fax' => 'fax',
            'Email' => 'email',
            'Website' => 'website',
            'ID' => 'description_2',
            'marker_id' => 'marker_id',
            'is_disabled' => 'is_disabled',
            'open_hours' => 'open_hours',
            'Brand' => 'brand',
            'Special' => 'special',
            'slug' => 'slug',
            'lang' => 'lang',
            'pending' => 'pending',
            'updated_on' => 'updated_on',
            'Logo' => 'logo_image',
            'Category' => 'categories',
            'order' => 'order',
			'Images' => 'banner',
            'ClientID' => 'customer-id'
			
        );

        // Write header
        $header = array_values($header_mapping);
        fputcsv($csv_file, $header);
    }

    // Write data
    foreach ($json_data as $row) {
        // Extract the identifier for the current row
        $current_identifier = $row['ID']; // Assuming 'ID' is the unique identifier

        // Check if the identifier already exists in the existing data
        if (isset($existing_data[$current_identifier])) {
            // If the identifier already exists, skip this row
            continue;
        }

        $new_row = array();
        foreach ($header_mapping as $key => $header) {
            // Check if the key exists in the row
            if (isset($row[$key])) {
                if ($key === 'Images' && is_array($row[$key])) {
                    // If 'Images' is an array, concatenate its elements into a single string
                    $new_row[] = implode(',', $row[$key]);
                } else {
                    $new_row[] = $row[$key];
                }
            } else {
                // If key doesn't exist, insert an empty value
                $new_row[] = '';
            }
        }
        fputcsv($csv_file, $new_row);
    }

    // Close CSV file
    fclose($csv_file);

    return true;
}



// Schedule cron job to periodically fetch JSON and update CSV
add_action('json_to_csv_cron', 'json_to_csv_cron_job');

function json_to_csv_cron_job() {
    // Fetch JSON data from URL
    $json_url = 'https://api.epublisher.world/location.ashx?storekey=ab2c8d3f-b4d8-4d37-9d3b-91f9d3cc2b21&call=get#json'; // Replace with your JSON URL
    $response = wp_remote_get($json_url);

    if (is_wp_error($response)) {
        error_log('Error fetching JSON data: ' . $response->get_error_message());
    } else {
        $json_data = json_decode(wp_remote_retrieve_body($response), true);
        if ($json_data === null) {
            error_log('Error decoding JSON data');
            return;
        }
        
        // Define CSV file path
        $csv_file_path = WP_CONTENT_DIR . '/uploads/agile-store-locator/cron/data.csv';
        // Convert JSON data to CSV
        if (json_to_csv($json_data, $csv_file_path)) {
            error_log('CSV file has been updated successfully');
        } else {
            error_log('Error occurred while converting JSON to CSV');
        }
    }
}

// Schedule the cron job to run every hour
// if (!wp_next_scheduled('json_to_csv_cron')) {
//     wp_schedule_event(time(), 'hourly', 'json_to_csv_cron');
// }



?>